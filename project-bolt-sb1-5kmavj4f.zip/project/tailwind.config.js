/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#0A2463',
          50: '#E6F0FF',
          100: '#CCE0FF',
          200: '#99C2FF',
          300: '#66A3FF',
          400: '#3385FF',
          500: '#0066FF',
          600: '#0052CC',
          700: '#003D99',
          800: '#002966',
          900: '#001433',
        },
        secondary: {
          DEFAULT: '#3E92CC',
          50: '#EBF5FC',
          100: '#D7EAF9',
          200: '#AFD6F3',
          300: '#87C1ED',
          400: '#5FACE7',
          500: '#3E92CC',
          600: '#2B76AB',
          700: '#1F5881',
          800: '#143B56',
          900: '#0A1D2B',
        },
        accent: {
          DEFAULT: '#732C7B',
          50: '#F3E6F4',
          100: '#E7CDEA',
          200: '#CF9CD5',
          300: '#B76ABF',
          400: '#9F39AA',
          500: '#732C7B',
          600: '#5C2363',
          700: '#451A4B',
          800: '#2E1132',
          900: '#170919',
        },
      },
      fontFamily: {
        sans: ['Montserrat', 'Inter', 'sans-serif'],
      },
      typography: (theme) => ({
        DEFAULT: {
          css: {
            maxWidth: 'none',
            color: theme('colors.gray.700'),
            '.lead': {
              color: theme('colors.gray.600'),
              fontSize: '1.25rem',
              fontWeight: '500',
              lineHeight: '1.6',
              marginBottom: '1.5rem',
            },
            h1: {
              color: theme('colors.gray.800'),
            },
            h2: {
              color: theme('colors.gray.800'),
              borderBottom: '1px solid ' + theme('colors.gray.200'),
              paddingBottom: '0.5rem',
              marginTop: '2.5rem',
              marginBottom: '1.5rem',
            },
            h3: {
              color: theme('colors.gray.800'),
              marginTop: '2rem',
              marginBottom: '1rem',
            },
            'blockquote': {
              fontWeight: '400',
              fontStyle: 'italic',
              color: theme('colors.gray.700'),
              borderLeftColor: theme('colors.purple.500'),
              borderLeftWidth: '0.25rem',
              borderLeftStyle: 'solid',
              paddingLeft: '1rem',
              marginTop: '1.5rem',
              marginBottom: '1.5rem',
            },
            'blockquote p:first-of-type::before': {
              content: '',
            },
            'blockquote p:last-of-type::after': {
              content: '',
            },
            code: {
              color: theme('colors.purple.700'),
              backgroundColor: theme('colors.gray.100'),
              padding: '0.2rem 0.4rem',
              borderRadius: '0.25rem',
              fontWeight: '500',
            },
            'code::before': {
              content: '',
            },
            'code::after': {
              content: '',
            },
            a: {
              color: theme('colors.purple.600'),
              textDecoration: 'none',
              '&:hover': {
                textDecoration: 'underline',
              },
            },
            'ul > li': {
              position: 'relative',
              paddingLeft: '1.5rem',
              marginBottom: '0.5rem',
            },
            'ul > li::before': {
              position: 'absolute',
              left: 0,
              top: '0.5rem',
              height: '0.375rem',
              width: '0.375rem',
              borderRadius: '50%',
              backgroundColor: theme('colors.gray.500'),
              content: '""',
            },
            '.image-container': {
              marginTop: '2rem',
              marginBottom: '2rem',
            },
            '.image-container img': {
              borderRadius: '0.5rem',
              overflow: 'hidden',
            },
            '.caption': {
              marginTop: '0.5rem',
              color: theme('colors.gray.500'),
              fontSize: '0.875rem',
              textAlign: 'center',
            },
          },
        },
      }),
    },
  },
  plugins: [
    require('@tailwindcss/typography'),
  ],
};

function addPlugin(pluginName) {
  try {
    return require(pluginName);
  } catch (e) {
    console.warn(`Warning: The plugin "${pluginName}" is not installed.`);
    return () => {};
  }
}