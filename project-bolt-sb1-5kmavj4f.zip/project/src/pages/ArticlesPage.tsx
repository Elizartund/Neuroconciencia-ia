import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Tag, Clock, ArrowRight } from 'lucide-react';

// Sample article data
const articles = [
  {
    id: 1,
    title: "La neuroplasticidad y el aprendizaje continuo",
    excerpt: "Cómo nuestro cerebro se adapta y cambia a lo largo de la vida, permitiéndonos aprender y desarrollar nuevas habilidades.",
    image: "https://images.pexels.com/photos/3771074/pexels-photo-3771074.jpeg",
    category: "Neurociencia",
    date: "24 Abr 2025",
    readTime: "8 min"
  },
  {
    id: 2,
    title: "IA y redes neuronales: imitando el cerebro humano",
    excerpt: "Un análisis de cómo las redes neuronales artificiales se inspiran en la estructura y funcionamiento del cerebro humano.",
    image: "https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg",
    category: "Inteligencia Artificial",
    date: "18 Abr 2025",
    readTime: "10 min"
  },
  {
    id: 3,
    title: "El impacto de la neurociencia en la educación moderna",
    excerpt: "Cómo los descubrimientos de la neurociencia están transformando las metodologías educativas y el aprendizaje.",
    image: "https://images.pexels.com/photos/3184405/pexels-photo-3184405.jpeg",
    category: "Neuroeducación",
    date: "10 Abr 2025",
    readTime: "7 min"
  },
  {
    id: 4,
    title: "Emociones y cerebro: la base neurológica de los sentimientos",
    excerpt: "Explorando los mecanismos cerebrales que generan y procesan nuestras emociones.",
    image: "https://images.pexels.com/photos/3807738/pexels-photo-3807738.jpeg",
    category: "Neurociencia",
    date: "02 Abr 2025",
    readTime: "9 min"
  },
  {
    id: 5,
    title: "Interfaz cerebro-máquina: el futuro de la interacción humano-computadora",
    excerpt: "Avances recientes en la tecnología que permite controlar dispositivos directamente con la mente.",
    image: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg",
    category: "Tecnología",
    date: "28 Mar 2025",
    readTime: "11 min"
  },
  {
    id: 6,
    title: "Meditación y mindfulness: efectos en la estructura cerebral",
    excerpt: "Cómo prácticas como la meditación y el mindfulness pueden cambiar físicamente nuestro cerebro.",
    image: "https://images.pexels.com/photos/3094230/pexels-photo-3094230.jpeg",
    category: "Bienestar",
    date: "20 Mar 2025",
    readTime: "6 min"
  }
];

// Categories
const categories = [
  "Todos",
  "Neurociencia",
  "Inteligencia Artificial",
  "Neuroeducación",
  "Tecnología",
  "Bienestar"
];

const ArticlesPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  
  // Filter articles based on search term and category
  const filteredArticles = articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          article.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "Todos" || article.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      {/* Header */}
      <section className="py-16 bg-gradient-to-br from-[#0A2463] via-[#3E92CC] to-[#732C7B] text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Artículos</h1>
          <p className="text-xl max-w-3xl mx-auto">
            Explora nuestros artículos sobre neurociencia, inteligencia artificial y sus aplicaciones.
          </p>
        </div>
      </section>
      
      {/* Search and Filter */}
      <section className="py-8 bg-white shadow-md">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="w-full md:w-auto relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Buscar artículos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full md:w-80 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
            
            <div className="w-full md:w-auto flex flex-wrap gap-2 justify-center">
              {categories.map((category, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-300 ${
                    selectedCategory === category
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* Articles Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          {filteredArticles.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-lg text-gray-600">No se encontraron artículos que coincidan con tu búsqueda.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredArticles.map(article => (
                <article 
                  key={article.id} 
                  className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300"
                >
                  <Link to={`/articles/${article.id}`}>
                    <div className="h-48 overflow-hidden">
                      <img 
                        src={article.image} 
                        alt={article.title} 
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                      />
                    </div>
                  </Link>
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <span className="px-3 py-1 bg-purple-100 text-purple-700 text-xs font-medium rounded-full flex items-center">
                        <Tag size={12} className="mr-1" />
                        {article.category}
                      </span>
                      <span className="text-gray-500 text-xs flex items-center">
                        <Clock size={12} className="mr-1" />
                        {article.readTime}
                      </span>
                    </div>
                    <Link to={`/articles/${article.id}`}>
                      <h2 className="text-xl font-bold mb-3 text-gray-800 hover:text-purple-600 transition-colors">
                        {article.title}
                      </h2>
                    </Link>
                    <p className="text-gray-600 mb-4 line-clamp-3">
                      {article.excerpt}
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-500">{article.date}</span>
                      <Link 
                        to={`/articles/${article.id}`} 
                        className="text-purple-600 font-medium flex items-center hover:text-purple-700 transition-colors"
                      >
                        Leer más <ArrowRight size={16} className="ml-1" />
                      </Link>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </section>
      
      {/* Newsletter */}
      <section className="py-16 bg-gradient-to-r from-purple-50 to-indigo-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6 text-gray-800">¿Te gustan nuestros artículos?</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Suscríbete a nuestro boletín y recibe nuestros últimos artículos directamente en tu bandeja de entrada.
          </p>
          <form className="max-w-md mx-auto flex flex-col sm:flex-row gap-2">
            <input 
              type="email" 
              placeholder="Tu correo electrónico" 
              className="flex-grow px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              required
            />
            <button 
              type="submit" 
              className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-colors duration-300"
            >
              Suscribirse
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default ArticlesPage;