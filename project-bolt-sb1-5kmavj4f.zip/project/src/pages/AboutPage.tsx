import React, { useEffect, useRef } from 'react';
import { BrainCircuit, Lightbulb, Cpu, Network } from 'lucide-react';

const AboutPage: React.FC = () => {
  const sectionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('fade-in-up');
          }
        });
      },
      { threshold: 0.1 }
    );
    
    const sections = sectionsRef.current?.children;
    if (sections) {
      Array.from(sections).forEach(section => {
        observer.observe(section);
      });
    }
    
    return () => {
      if (sections) {
        Array.from(sections).forEach(section => {
          observer.unobserve(section);
        });
      }
    };
  }, []);

  return (
    <div className="pt-16 bg-gray-50">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-[#0A2463] via-[#3E92CC] to-[#732C7B] text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            ¿Qué es la Neurociencia?
          </h1>
          <p className="text-xl max-w-3xl mx-auto">
            La neurociencia es la ciencia que estudia el sistema nervioso: su estructura, funciones 
            y cómo impacta en nuestras emociones, decisiones y comportamientos.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-16" ref={sectionsRef}>
        {/* Introduction */}
        <section className="mb-16 opacity-0">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-4 text-gray-800">El fascinante mundo del cerebro</h2>
              <p className="text-lg text-gray-600 mb-4">
                El cerebro humano es uno de los órganos más complejos y fascinantes del cuerpo. Con sus aproximadamente 
                86 mil millones de neuronas y billones de conexiones, es el centro de control que regula todas nuestras 
                funciones, pensamientos, emociones y comportamientos.
              </p>
              <p className="text-lg text-gray-600">
                La neurociencia moderna utiliza tecnologías avanzadas como la resonancia magnética funcional (fMRI), 
                la electroencefalografía (EEG) y técnicas de optogenética para estudiar este órgano en tiempo real, 
                revelando sus secretos y mecanismos.
              </p>
            </div>
            <div className="md:w-1/2">
              <div className="rounded-2xl overflow-hidden shadow-xl">
                <img 
                  src="https://images.pexels.com/photos/3825586/pexels-photo-3825586.jpeg" 
                  alt="Cerebro humano" 
                  className="w-full h-auto"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Key Areas */}
        <section className="mb-16 opacity-0">
          <h2 className="text-3xl font-bold mb-8 text-center text-gray-800">Áreas clave de la neurociencia</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                icon: <BrainCircuit className="w-12 h-12 text-purple-600" />,
                title: "Neurociencia Cognitiva",
                description: "Estudia los procesos mentales como la percepción, la memoria, el razonamiento y la toma de decisiones, explorando la base biológica de nuestra cognición."
              },
              {
                icon: <Lightbulb className="w-12 h-12 text-yellow-500" />,
                title: "Neurociencia Conductual",
                description: "Investiga cómo el cerebro genera comportamientos y cómo estos comportamientos pueden ser modificados por experiencias y aprendizaje."
              },
              {
                icon: <Cpu className="w-12 h-12 text-blue-600" />,
                title: "Neurociencia Computacional",
                description: "Utiliza modelos matemáticos y simulaciones por computadora para entender cómo funciona el cerebro, creando sistemas que emulan sus procesos."
              },
              {
                icon: <Network className="w-12 h-12 text-green-600" />,
                title: "Neurociencia Social",
                description: "Explora cómo el cerebro media las interacciones sociales, el reconocimiento de emociones, la empatía y otros aspectos de nuestro comportamiento social."
              }
            ].map((area, index) => (
              <div 
                key={index} 
                className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <div className="mb-4">{area.icon}</div>
                <h3 className="text-xl font-bold mb-3 text-gray-800">{area.title}</h3>
                <p className="text-gray-600">{area.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Neuroplasticity */}
        <section className="mb-16 opacity-0">
          <div className="bg-white p-8 rounded-2xl shadow-lg">
            <h2 className="text-3xl font-bold mb-6 text-center text-gray-800">Neuroplasticidad: El cerebro adaptable</h2>
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="md:w-1/2">
                <img 
                  src="https://images.pexels.com/photos/3184423/pexels-photo-3184423.jpeg" 
                  alt="Aprendizaje y desarrollo cerebral" 
                  className="rounded-xl shadow-md"
                />
              </div>
              <div className="md:w-1/2">
                <p className="text-lg text-gray-600 mb-4">
                  Uno de los descubrimientos más revolucionarios de la neurociencia moderna es la neuroplasticidad: 
                  la capacidad del cerebro para cambiar, reorganizarse y adaptarse a lo largo de toda la vida.
                </p>
                <p className="text-lg text-gray-600 mb-4">
                  Esta capacidad permite que nuestro cerebro forme nuevas conexiones neuronales, fortalezca las existentes 
                  o incluso reasigne funciones de áreas dañadas a regiones sanas, lo que es fundamental para:
                </p>
                <ul className="space-y-2 text-gray-600 list-disc pl-5">
                  <li>El aprendizaje de nuevas habilidades</li>
                  <li>La recuperación después de lesiones cerebrales</li>
                  <li>La adaptación a cambios en el entorno</li>
                  <li>El desarrollo de la memoria y la cognición</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Neurociencia e IA */}
        <section className="opacity-0">
          <h2 className="text-3xl font-bold mb-8 text-center text-gray-800">La convergencia de neurociencia e IA</h2>
          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-8 rounded-2xl shadow-lg">
            <div className="flex flex-col md:flex-row gap-8">
              <div className="md:w-1/2">
                <h3 className="text-2xl font-bold mb-4 text-gray-800">Una relación bidireccional</h3>
                <p className="text-lg text-gray-600 mb-4">
                  La relación entre la neurociencia y la inteligencia artificial es bidireccional y sinérgica:
                </p>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start">
                    <span className="mr-2 text-purple-600">→</span>
                    <span>La neurociencia inspira nuevos algoritmos de IA basados en el funcionamiento del cerebro humano.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-purple-600">→</span>
                    <span>La IA ayuda a analizar enormes conjuntos de datos neurológicos y a crear modelos del cerebro.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2 text-purple-600">→</span>
                    <span>Juntas están revolucionando campos como la medicina, la educación y la comprensión de la cognición humana.</span>
                  </li>
                </ul>
              </div>
              <div className="md:w-1/2">
                <div className="rounded-xl overflow-hidden shadow-md">
                  <img 
                    src="https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg" 
                    alt="Inteligencia Artificial y Neurociencia" 
                    className="w-full h-auto"
                  />
                </div>
                <div className="mt-4 p-4 bg-white rounded-lg shadow-md">
                  <p className="text-gray-700 italic">
                    "Comprender cómo funciona el cerebro humano es fundamental para desarrollar sistemas de IA más avanzados, 
                    mientras que las herramientas de IA nos permiten analizar el cerebro de formas antes imposibles."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default AboutPage;