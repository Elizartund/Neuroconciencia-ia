import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { BrainCircuit, BookOpen, MessageCircle, Zap } from 'lucide-react';
import NeuralAnimation from '../components/NeuralAnimation';

const HomePage: React.FC = () => {
  const featuresRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('fade-in-up');
          }
        });
      },
      { threshold: 0.1 }
    );
    
    const children = featuresRef.current?.children;
    if (children) {
      Array.from(children).forEach(child => {
        observer.observe(child);
      });
    }
    
    return () => {
      if (children) {
        Array.from(children).forEach(child => {
          observer.unobserve(child);
        });
      }
    };
  }, []);
  
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center relative bg-gradient-to-br from-[#0A2463] via-[#3E92CC] to-[#732C7B] text-white">
        <div className="absolute inset-0 opacity-20">
          <NeuralAnimation />
        </div>
        <div className="container mx-auto px-4 py-20 z-10 text-center">
          <div className="staggered-animation">
            <div className="inline-block mb-6 p-2 rounded-full bg-white/10 backdrop-blur">
              <BrainCircuit size={48} className="text-white neuron-pulse" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Neuroconciencia-IA</h1>
            <p className="text-xl md:text-2xl max-w-2xl mx-auto mb-8">
              Explorando la intersección entre neurociencia, conciencia e inteligencia artificial.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link 
                to="/articles" 
                className="px-8 py-3 bg-purple-600 hover:bg-purple-700 rounded-full font-medium transition-colors duration-300"
              >
                Explorar Artículos
              </Link>
              <Link 
                to="/demo" 
                className="px-8 py-3 bg-white/10 hover:bg-white/20 backdrop-blur rounded-full font-medium transition-colors duration-300"
              >
                Ver Demostración
              </Link>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white/10 to-transparent"></div>
      </section>
      
      {/* Intro Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
              ¿Qué es la <span className="text-purple-600">Neurociencia</span>?
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              La neurociencia es el estudio científico del sistema nervioso, que explora cómo el cerebro 
              y el resto del sistema nervioso funcionan y afectan el comportamiento, las emociones y la cognición. 
              En Neuroconciencia-IA, exploramos la fascinante conexión entre la neurociencia y la inteligencia artificial.
            </p>
          </div>
          
          <div 
            ref={featuresRef}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {[
              {
                icon: <BrainCircuit className="w-12 h-12 text-purple-600" />,
                title: "Neuroplasticidad",
                description: "Descubre cómo nuestro cerebro tiene la asombrosa capacidad de reorganizarse a lo largo de la vida, formando nuevas conexiones y adaptándose a nuevas experiencias."
              },
              {
                icon: <Zap className="w-12 h-12 text-blue-600" />,
                title: "Cerebro y Emociones",
                description: "Explora la base neurológica de nuestras emociones y cómo el cerebro procesa y regula nuestros sentimientos."
              },
              {
                icon: <BookOpen className="w-12 h-12 text-indigo-600" />,
                title: "Neuroeducación",
                description: "Aprende cómo aplicar los hallazgos de la neurociencia para mejorar los procesos de enseñanza y aprendizaje."
              }
            ].map((feature, index) => (
              <div 
                key={index} 
                className="opacity-0 bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100"
              >
                <div className="mb-6">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-3 text-gray-800">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* IA Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <div className="lg:w-1/2">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">
                La Convergencia de <span className="text-purple-600">Neurociencia e IA</span>
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed mb-8">
                La inteligencia artificial y la neurociencia están transformando nuestra comprensión del cerebro
                y abriendo nuevas posibilidades para tratar enfermedades, mejorar la educación y desarrollar tecnologías más intuitivas.
              </p>
              <Link 
                to="/demo" 
                className="inline-block px-8 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-full font-medium transition-colors duration-300"
              >
                Explorar Demostración
              </Link>
            </div>
            <div className="lg:w-1/2 relative">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl">
                <img 
                  src="https://images.pexels.com/photos/8439093/pexels-photo-8439093.jpeg" 
                  alt="Cerebro y tecnología" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 p-4 bg-white rounded-xl shadow-lg max-w-xs brain-wave">
                <p className="text-gray-800 font-medium">
                  "La IA nos ayuda a descifrar los patrones complejos del cerebro humano."
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-purple-700 to-indigo-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Únete a nuestra comunidad
          </h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">
            Suscríbete para recibir las últimas investigaciones, artículos y eventos sobre neurociencia e inteligencia artificial.
          </p>
          <form className="max-w-md mx-auto flex flex-col sm:flex-row gap-2 mb-8">
            <input 
              type="email" 
              placeholder="Tu correo electrónico" 
              className="flex-grow px-4 py-3 rounded-full text-gray-800 focus:outline-none focus:ring-2 focus:ring-purple-300"
            />
            <button 
              type="submit" 
              className="px-6 py-3 bg-purple-500 hover:bg-purple-600 rounded-full font-medium transition-colors duration-300"
            >
              Suscribirse
            </button>
          </form>
          <p className="text-sm text-purple-200">
            Nos comprometemos a proteger tus datos y nunca compartir tu información.
          </p>
        </div>
      </section>
    </div>
  );
};

export default HomePage;