import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, Clock, User, Tag, Share2, BookmarkPlus } from 'lucide-react';

// Sample article data (expanded version)
const articlesData = [
  {
    id: 1,
    title: "La neuroplasticidad y el aprendizaje continuo",
    excerpt: "Cómo nuestro cerebro se adapta y cambia a lo largo de la vida, permitiéndonos aprender y desarrollar nuevas habilidades.",
    image: "https://images.pexels.com/photos/3771074/pexels-photo-3771074.jpeg",
    category: "Neurociencia",
    date: "24 Abr 2025",
    readTime: "8 min",
    author: "Dr. María González",
    authorImage: "https://images.pexels.com/photos/3767392/pexels-photo-3767392.jpeg?auto=compress&cs=tinysrgb&w=150",
    content: `
      <p class="lead">La neuroplasticidad es la extraordinaria capacidad del cerebro para reorganizarse formando nuevas conexiones neuronales a lo largo de la vida. Esta capacidad permite que el cerebro se adapte a nuevas situaciones o a cambios en el entorno.</p>
      
      <h2>¿Qué es la neuroplasticidad?</h2>
      
      <p>Durante mucho tiempo se pensó que el cerebro era un órgano fisiológicamente estático. Sin embargo, hoy sabemos que el cerebro cambia constantemente su estructura y función basándose en la experiencia, el pensamiento y las acciones. Esta capacidad, conocida como neuroplasticidad, es lo que nos permite aprender nuevas habilidades, adaptarnos a diferentes situaciones y recuperarnos de lesiones cerebrales.</p>
      
      <p>La neuroplasticidad ocurre a varios niveles, desde cambios moleculares hasta modificaciones a gran escala en el mapeo cortical. Algunos de los mecanismos incluyen:</p>
      
      <ul>
        <li>Fortalecimiento o debilitamiento de sinapsis existentes</li>
        <li>Formación de nuevas sinapsis entre neuronas</li>
        <li>Modificación de la eficacia de las sinapsis</li>
        <li>Remapeo cortical después de una lesión</li>
      </ul>

      <div class="image-container">
        <img src="https://images.pexels.com/photos/3825586/pexels-photo-3825586.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Cerebro humano" />
        <p class="caption">Las conexiones neuronales en el cerebro cambian constantemente en respuesta a nuevas experiencias.</p>
      </div>
      
      <h2>Neuroplasticidad y aprendizaje</h2>
      
      <p>El aprendizaje es quizás la manifestación más común de la neuroplasticidad. Cuando aprendemos algo nuevo, nuestro cerebro crea o refuerza conexiones entre neuronas. Con la práctica repetida, estas conexiones se fortalecen y el aprendizaje se consolida.</p>
      
      <p>Un ejemplo fascinante de neuroplasticidad en acción es el estudio de los taxistas de Londres. Los investigadores encontraron que los taxistas tenían un hipocampo (región cerebral asociada con la memoria espacial) más grande que el promedio, especialmente en aquellos con más años de experiencia. Sus cerebros se habían adaptado físicamente para almacenar el complejo mapa mental de la ciudad.</p>
      
      <blockquote>
        "El cerebro es como un músculo. Cuanto más lo usas, más crece. Cuanto más desafías tu cerebro aprendiendo algo nuevo, más nuevas conexiones creas en él." - Dr. Tara Swart
      </blockquote>
      
      <h2>Neuroplasticidad a lo largo de la vida</h2>
      
      <p>Aunque la neuroplasticidad es más pronunciada durante la infancia (periodo crítico), ahora sabemos que continúa a lo largo de toda la vida adulta. Esto tiene importantes implicaciones para el envejecimiento saludable y la recuperación de lesiones cerebrales.</p>
      
      <p>Los estudios muestran que las personas mayores que permanecen mentalmente activas presentan menos deterioro cognitivo. Actividades como aprender un nuevo idioma, tocar un instrumento musical o incluso jugar videojuegos específicamente diseñados pueden estimular la neuroplasticidad en adultos mayores.</p>
      
      <h2>Aplicaciones prácticas</h2>
      
      <p>El conocimiento sobre la neuroplasticidad ha revolucionado varios campos:</p>
      
      <ul>
        <li><strong>Rehabilitación neurológica:</strong> Nuevos enfoques para pacientes con accidentes cerebrovasculares y lesiones cerebrales.</li>
        <li><strong>Educación:</strong> Métodos de enseñanza basados en cómo el cerebro aprende mejor.</li>
        <li><strong>Tratamiento de trastornos mentales:</strong> Terapias que aprovechan la capacidad del cerebro para cambiar sus patrones de actividad.</li>
        <li><strong>Mejora cognitiva:</strong> Programas diseñados para mantener y mejorar las funciones cerebrales.</li>
      </ul>
      
      <div class="image-container">
        <img src="https://images.pexels.com/photos/3862372/pexels-photo-3862372.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Aprendizaje y desarrollo" />
        <p class="caption">El aprendizaje continuo promueve la formación de nuevas conexiones neuronales.</p>
      </div>
      
      <h2>Conclusión</h2>
      
      <p>La neuroplasticidad nos muestra que nuestro cerebro es mucho más adaptable y dinámico de lo que anteriormente se creía. Esta comprensión no solo ha revolucionado las neurociencias, sino que también nos ofrece una visión esperanzadora sobre nuestro potencial para aprender, cambiar y crecer a cualquier edad.</p>
      
      <p>Como dijo Santiago Ramón y Cajal, neurocientífico ganador del Premio Nobel: "Todo hombre puede ser, si se lo propone, escultor de su propio cerebro." La neuroplasticidad nos da la base científica para esta profunda intuición.</p>
    `
  },
  {
    id: 2,
    title: "IA y redes neuronales: imitando el cerebro humano",
    excerpt: "Un análisis de cómo las redes neuronales artificiales se inspiran en la estructura y funcionamiento del cerebro humano.",
    image: "https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg",
    category: "Inteligencia Artificial",
    date: "18 Abr 2025",
    readTime: "10 min",
    author: "Dr. Carlos Ramírez",
    authorImage: "https://images.pexels.com/photos/5384445/pexels-photo-5384445.jpeg?auto=compress&cs=tinysrgb&w=150",
    content: `
      <p class="lead">Las redes neuronales artificiales, la tecnología que impulsa muchos de los avances actuales en inteligencia artificial, se inspiraron originalmente en el funcionamiento del cerebro humano. Aunque hoy son muy diferentes de sus contrapartes biológicas, esta inspiración sigue siendo fundamental.</p>
      
      <h2>Del cerebro a la máquina: una breve historia</h2>
      
      <p>En 1943, Warren McCulloch y Walter Pitts propusieron el primer modelo matemático de una neurona artificial, inspirado directamente en las neuronas biológicas. Este modelo simplificado intentaba replicar cómo las neuronas reciben señales de entrada, las integran y producen una señal de salida cuando se supera cierto umbral.</p>
      
      <p>Frank Rosenblatt desarrolló posteriormente el perceptrón en 1958, capaz de aprender a partir de ejemplos. Sin embargo, las limitaciones identificadas por Minsky y Papert en 1969 llevaron a un declive en la investigación, conocido como el "invierno de la IA".</p>
      
      <p>El resurgimiento llegó en los años 80 con el algoritmo de retropropagación y las redes multicapa, capaces de superar las limitaciones del perceptrón simple. Desde entonces, con el aumento del poder computacional y la disponibilidad de grandes conjuntos de datos, las redes neuronales han evolucionado enormemente.</p>
      
      <div class="image-container">
        <img src="https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Representación de redes neuronales" />
        <p class="caption">Representación visual de una red neuronal artificial con múltiples capas.</p>
      </div>
      
      <h2>Paralelos con el cerebro humano</h2>
      
      <p>Aunque las redes neuronales artificiales actuales son simplificaciones extremas del cerebro, comparten algunos principios fundamentales:</p>
      
      <ul>
        <li><strong>Arquitectura distribuida:</strong> Tanto el cerebro como las redes neuronales procesan información a través de múltiples unidades interconectadas.</li>
        <li><strong>Aprendizaje adaptativo:</strong> Ambos sistemas modifican sus conexiones basándose en la experiencia.</li>
        <li><strong>Tolerancia a fallos:</strong> El daño parcial no necesariamente resulta en un colapso total del sistema.</li>
        <li><strong>Generalización:</strong> Pueden aplicar conocimientos previos a situaciones nuevas pero similares.</li>
      </ul>
      
      <blockquote>
        "Si queremos construir máquinas que puedan hacer todas las cosas que los humanos hacen, entonces necesitamos inspirarnos en la única prueba existente de que tales máquinas son posibles: el cerebro humano." - Geoffrey Hinton
      </blockquote>
      
      <h2>Diferencias clave</h2>
      
      <p>A pesar de las similitudes conceptuales, las diferencias son enormes:</p>
      
      <ul>
        <li>El cerebro humano tiene aproximadamente 86 mil millones de neuronas con trillones de conexiones. Incluso los modelos de IA más grandes tienen órdenes de magnitud menos parámetros.</li>
        <li>Las neuronas biológicas son extremadamente complejas y realizan cálculos químicos y eléctricos sofisticados, mientras que las neuronas artificiales realizan operaciones matemáticas relativamente simples.</li>
        <li>El cerebro opera con un consumo energético extremadamente eficiente (aproximadamente 20 vatios), mientras que entrenar grandes modelos de IA puede consumir megavatios de energía.</li>
        <li>El cerebro es un sistema analógico, continuo y paralelo; las redes neuronales artificiales son generalmente digitales y, aunque paralelas, operan de manera diferente.</li>
      </ul>
      
      <h2>El futuro: convergencia neurociencia-IA</h2>
      
      <p>La relación entre neurociencia e IA es cada vez más bidireccional:</p>
      
      <ul>
        <li>Los nuevos descubrimientos en neurociencia están inspirando arquitecturas de IA más sofisticadas.</li>
        <li>Los modelos de IA ayudan a los neurocientíficos a entender mejor el cerebro humano.</li>
        <li>Campos emergentes como la neuromorfología buscan crear hardware especializado que imite más fielmente los principios de computación del cerebro.</li>
      </ul>
      
      <div class="image-container">
        <img src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Investigación en IA" />
        <p class="caption">Investigadores trabajando en el desarrollo de nuevos algoritmos de aprendizaje profundo.</p>
      </div>
      
      <h2>Conclusión</h2>
      
      <p>Las redes neuronales artificiales, aunque inspiradas en el cerebro, han evolucionado en direcciones propias dictadas por consideraciones prácticas de ingeniería. Sin embargo, esta inspiración biológica sigue siendo valiosa y el diálogo entre neurociencia e IA promete impulsar ambos campos en el futuro.</p>
      
      <p>A medida que nuestra comprensión del cerebro sigue avanzando, es probable que veamos nuevas generaciones de sistemas de IA que incorporen más principios del funcionamiento cerebral, potencialmente desbloqueando capacidades que actualmente están fuera del alcance de los sistemas artificiales.</p>
    `
  },
  {
    id: 3,
    title: "El impacto de la neurociencia en la educación moderna",
    excerpt: "Cómo los descubrimientos de la neurociencia están transformando las metodologías educativas y el aprendizaje.",
    image: "https://images.pexels.com/photos/3184405/pexels-photo-3184405.jpeg",
    category: "Neuroeducación",
    date: "10 Abr 2025",
    readTime: "7 min",
    author: "Dra. Laura Sánchez",
    authorImage: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150",
    content: `
      <p class="lead">La neuroeducación, también conocida como neurociencia educativa, es un campo emergente que busca aplicar los hallazgos de la neurociencia para mejorar las prácticas de enseñanza y aprendizaje. Este enfoque interdisciplinario está transformando nuestra comprensión de cómo aprendemos y cómo deberíamos enseñar.</p>
      
      <h2>¿Qué es la neuroeducación?</h2>
      
      <p>La neuroeducación integra conocimientos de la neurociencia, la psicología cognitiva y la pedagogía para desarrollar métodos de enseñanza más efectivos y basados en evidencia. En lugar de basarse únicamente en tradiciones educativas o teorías sin verificar, busca fundamentar las prácticas educativas en nuestra comprensión del funcionamiento cerebral.</p>
      
      <p>Este campo reconoce que el aprendizaje implica cambios físicos en el cerebro a través de la neuroplasticidad, y que comprender estos procesos puede ayudarnos a diseñar experiencias educativas más efectivas.</p>
      
      <div class="image-container">
        <img src="https://images.pexels.com/photos/8613089/pexels-photo-8613089.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Estudiantes en clase" />
        <p class="caption">Los métodos de enseñanza basados en neurociencia fomentan el aprendizaje activo y multisensorial.</p>
      </div>
      
      <h2>Principios clave de la neuroeducación</h2>
      
      <p>La investigación en neurociencia ha revelado varios principios importantes que tienen implicaciones directas para la educación:</p>
      
      <h3>1. La emoción es fundamental para el aprendizaje</h3>
      
      <p>El sistema límbico, responsable de procesar las emociones, está estrechamente conectado con las áreas del cerebro involucradas en la atención y la memoria. La investigación muestra que la información con contenido emocional se recuerda mejor que la información neutral. Esto sugiere que crear entornos de aprendizaje emocionalmente positivos y contenido que despierte interés puede mejorar significativamente la retención.</p>
      
      <h3>2. El cerebro busca patrones</h3>
      
      <p>Nuestro cerebro ha evolucionado para detectar patrones y crear significado. Los estudiantes aprenden mejor cuando pueden conectar nueva información con conocimientos previos y cuando el material se presenta de manera que les permite descubrir relaciones y patrones por sí mismos.</p>
      
      <h3>3. El ejercicio físico mejora el aprendizaje</h3>
      
      <p>La actividad física aumenta el flujo sanguíneo al cerebro, promueve la neurogénesis (formación de nuevas neuronas) en el hipocampo, y libera factores de crecimiento neuronal. Los estudios muestran que el ejercicio regular mejora la concentración, la memoria y las funciones ejecutivas.</p>
      
      <blockquote>
        "Lo que la neurociencia está enseñándonos es que la pregunta no es si alguien es inteligente o no, sino cómo es inteligente." - Dr. David Sousa
      </blockquote>
      
      <h3>4. El sueño consolida el aprendizaje</h3>
      
      <p>Durante el sueño, especialmente en las fases de ondas lentas y REM, el cerebro procesa y consolida la información adquirida durante el día. La privación del sueño afecta negativamente la capacidad de aprender nueva información y de recuperar lo aprendido.</p>
      
      <h3>5. La atención es selectiva y limitada</h3>
      
      <p>El cerebro no puede procesar toda la información sensorial disponible simultáneamente. La capacidad de atención es limitada, y dividirla entre múltiples tareas reduce la eficiencia del aprendizaje. Las prácticas educativas efectivas deben considerar estas limitaciones y estructurar el aprendizaje para maximizar la atención.</p>
      
      <h2>Aplicaciones prácticas en el aula</h2>
      
      <p>Estos principios neurocientíficos están transformando las prácticas educativas de varias maneras:</p>
      
      <ul>
        <li><strong>Aprendizaje espaciado:</strong> Distribuir el estudio en múltiples sesiones cortas en lugar de una sola sesión prolongada aprovecha cómo el cerebro consolida la memoria.</li>
        <li><strong>Evaluación formativa:</strong> Pruebas frecuentes de bajo riesgo mejoran la retención más que simplemente releer material.</li>
        <li><strong>Aprendizaje multisensorial:</strong> Involucrar múltiples sentidos crea más conexiones neuronales y mejora la retención.</li>
        <li><strong>Descansos activos:</strong> Intercalar períodos cortos de actividad física durante el día escolar mejora la atención y el aprendizaje.</li>
        <li><strong>Metacognición:</strong> Enseñar a los estudiantes sobre cómo aprende el cerebro les ayuda a desarrollar estrategias de aprendizaje más efectivas.</li>
      </ul>
      
      <div class="image-container">
        <img src="https://images.pexels.com/photos/8926546/pexels-photo-8926546.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Educación moderna" />
        <p class="caption">Los entornos de aprendizaje modernos incorporan principios de neuroeducación para optimizar el aprendizaje.</p>
      </div>
      
      <h2>Desafíos y precauciones</h2>
      
      <p>A pesar de su potencial, la neuroeducación enfrenta varios desafíos:</p>
      
      <ul>
        <li>La brecha entre la investigación de laboratorio y aplicaciones prácticas en el aula sigue siendo significativa.</li>
        <li>Existe el riesgo de "neuromitos" - interpretaciones erróneas o simplificaciones excesivas de la investigación neurocientífica.</li>
        <li>La formación adecuada de educadores en principios neurocientíficos requiere tiempo y recursos.</li>
      </ul>
      
      <h2>El futuro de la neuroeducación</h2>
      
      <p>El campo continúa evolucionando rápidamente, con desarrollos prometedores en varias áreas:</p>
      
      <ul>
        <li>Tecnologías como la neuroimagen funcional están permitiendo un estudio más detallado del cerebro durante el aprendizaje en entornos naturales.</li>
        <li>El desarrollo de aplicaciones y herramientas educativas adaptativas que responden a las necesidades individuales de los estudiantes.</li>
        <li>Mayor colaboración entre neurocientíficos, psicólogos cognitivos y educadores para desarrollar y evaluar intervenciones educativas.</li>
      </ul>
      
      <h2>Conclusión</h2>
      
      <p>La neuroeducación representa un enfoque prometedor para transformar las prácticas educativas basándolas en una comprensión científica de cómo el cerebro aprende. Aunque todavía estamos en las etapas iniciales de este campo, el potencial para mejorar la efectividad de la educación es inmenso.</p>
      
      <p>Al continuar cerrando la brecha entre la investigación neurocientífica y la práctica educativa, podemos crear sistemas educativos que se alineen mejor con la forma natural en que el cerebro aprende, haciendo que el aprendizaje sea más efectivo, eficiente y agradable para todos los estudiantes.</p>
    `
  },
  {
    id: 4,
    title: "Emociones y cerebro: la base neurológica de los sentimientos",
    excerpt: "Explorando los mecanismos cerebrales que generan y procesan nuestras emociones.",
    image: "https://images.pexels.com/photos/3807738/pexels-photo-3807738.jpeg",
    category: "Neurociencia",
    date: "02 Abr 2025",
    readTime: "9 min",
    author: "Dr. Alejandro Morales",
    authorImage: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150",
    content: `<p>Contenido completo del artículo sobre emociones y cerebro...</p>`
  },
  {
    id: 5,
    title: "Interfaz cerebro-máquina: el futuro de la interacción humano-computadora",
    excerpt: "Avances recientes en la tecnología que permite controlar dispositivos directamente con la mente.",
    image: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg",
    category: "Tecnología",
    date: "28 Mar 2025",
    readTime: "11 min",
    author: "Ing. Sofia Torres",
    authorImage: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150",
    content: `<p>Contenido completo del artículo sobre interfaz cerebro-máquina...</p>`
  },
  {
    id: 6,
    title: "Meditación y mindfulness: efectos en la estructura cerebral",
    excerpt: "Cómo prácticas como la meditación y el mindfulness pueden cambiar físicamente nuestro cerebro.",
    image: "https://images.pexels.com/photos/3094230/pexels-photo-3094230.jpeg",
    category: "Bienestar",
    date: "20 Mar 2025",
    readTime: "6 min",
    author: "Dr. Miguel Luna",
    authorImage: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150",
    content: `<p>Contenido completo del artículo sobre meditación...</p>`
  }
];

const ArticleDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [article, setArticle] = useState<typeof articlesData[0] | null>(null);
  
  useEffect(() => {
    if (id) {
      const foundArticle = articlesData.find(a => a.id === parseInt(id));
      if (foundArticle) {
        setArticle(foundArticle);
        // Set the document title
        document.title = `${foundArticle.title} | Neuroconciencia-IA`;
      }
    }
    
    // Reset title when component unmounts
    return () => {
      document.title = 'Neuroconciencia-IA';
    };
  }, [id]);
  
  if (!article) {
    return (
      <div className="pt-24 pb-16 text-center">
        <p className="text-xl text-gray-600">Artículo no encontrado</p>
        <Link 
          to="/articles" 
          className="inline-block mt-4 px-6 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
        >
          Volver a artículos
        </Link>
      </div>
    );
  }
  
  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      {/* Header */}
      <div className="w-full h-96 relative">
        <img 
          src={article.image} 
          alt={article.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
          <div className="container mx-auto px-4 py-8">
            <div className="max-w-4xl">
              <span className="inline-block px-3 py-1 bg-purple-600 text-white text-sm font-medium rounded-full mb-4">
                {article.category}
              </span>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
                {article.title}
              </h1>
            </div>
          </div>
        </div>
      </div>
      
      {/* Article Metadata */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto py-4 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center">
              <img 
                src={article.authorImage} 
                alt={article.author} 
                className="w-10 h-10 rounded-full mr-3"
              />
              <div>
                <div className="flex items-center">
                  <User size={14} className="text-gray-500 mr-1" />
                  <span className="text-sm font-medium text-gray-800">{article.author}</span>
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Calendar size={14} className="mr-1" />
                  <span className="mr-3">{article.date}</span>
                  <Clock size={14} className="mr-1" />
                  <span>{article.readTime}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <button className="p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors">
                <BookmarkPlus size={18} className="text-gray-600" />
              </button>
              <button className="p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors">
                <Share2 size={18} className="text-gray-600" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Article Content */}
      <article className="py-10">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div 
              className="prose prose-lg max-w-none prose-headings:text-gray-800 prose-headings:font-bold prose-p:text-gray-600 prose-a:text-purple-600"
              dangerouslySetInnerHTML={{ __html: article.content }}
            />
            
            {/* Tags */}
            <div className="mt-10 pt-6 border-t">
              <h3 className="text-lg font-semibold text-gray-800 mb-3 flex items-center">
                <Tag size={18} className="mr-2" />
                Etiquetas
              </h3>
              <div className="flex flex-wrap gap-2">
                {[article.category, 'Neuroconciencia', 'Investigación'].map((tag, index) => (
                  <span 
                    key={index} 
                    className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full hover:bg-gray-200 transition-colors cursor-pointer"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
            
            {/* Author Bio */}
            <div className="mt-10 bg-gray-50 rounded-xl p-6">
              <div className="flex items-start gap-4">
                <img 
                  src={article.authorImage} 
                  alt={article.author} 
                  className="w-16 h-16 rounded-full"
                />
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">{article.author}</h3>
                  <p className="text-gray-600 mt-1">
                    Investigador especializado en neurociencia y educación. Autor de múltiples publicaciones científicas sobre el funcionamiento del cerebro y su relación con el aprendizaje.
                  </p>
                </div>
              </div>
            </div>
            
            {/* Navigation */}
            <div className="mt-10 flex justify-between">
              <Link 
                to="/articles" 
                className="inline-flex items-center text-purple-600 hover:text-purple-700 transition-colors"
              >
                <ArrowLeft size={18} className="mr-2" />
                Volver a artículos
              </Link>
            </div>
          </div>
        </div>
      </article>
      
      {/* Related Articles */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-8 text-center text-gray-800">Artículos relacionados</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {articlesData
              .filter(a => a.id !== article.id && a.category === article.category)
              .slice(0, 3)
              .map(relatedArticle => (
                <article 
                  key={relatedArticle.id} 
                  className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <Link to={`/articles/${relatedArticle.id}`}>
                    <div className="h-40 overflow-hidden">
                      <img 
                        src={relatedArticle.image} 
                        alt={relatedArticle.title} 
                        className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                      />
                    </div>
                  </Link>
                  <div className="p-4">
                    <span className="text-xs font-medium text-purple-600 mb-1 block">
                      {relatedArticle.category}
                    </span>
                    <Link to={`/articles/${relatedArticle.id}`}>
                      <h3 className="text-lg font-bold mb-2 text-gray-800 hover:text-purple-600 transition-colors">
                        {relatedArticle.title}
                      </h3>
                    </Link>
                    <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                      {relatedArticle.excerpt}
                    </p>
                    <Link 
                      to={`/articles/${relatedArticle.id}`} 
                      className="text-sm text-purple-600 font-medium hover:text-purple-700 transition-colors"
                    >
                      Leer más →
                    </Link>
                  </div>
                </article>
              ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default ArticleDetail;