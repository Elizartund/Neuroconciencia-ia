import React, { useState, useEffect, useRef } from 'react';
import { PlusCircle, Trash2, Download, HelpCircle, Brain } from 'lucide-react';
import CodeHighlighter from '../components/CodeHighlighter';

interface DataPoint {
  Delta: number;
  Theta: number;
  Alpha: number;
  Beta: number;
  Gamma: number;
  Noise: number;
  State: string;
}

const MODEL_CODE = `# Modelo de IA para clasificación de estados cerebrales
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.regularizers import l2
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# Generación de datos sintéticos realistas
np.random.seed(42)

estados = {
    "Anxiety": {"Delta": (0.1, 1.0), "Theta": (0.5, 3.0), "Alpha": (2.0, 6.0), "Beta": (8.0, 20.0), "Gamma": (4.0, 18.0)},
    "Euphoria": {"Delta": (0.2, 1.8), "Theta": (0.8, 4.0), "Alpha": (6.0, 14.0), "Beta": (10.0, 28.0), "Gamma": (20.0, 45.0)},
    "Focus": {"Delta": (0.1, 0.8), "Theta": (0.2, 2.0), "Alpha": (3.0, 10.0), "Beta": (15.0, 35.0), "Gamma": (18.0, 40.0)},
    "Happiness": {"Delta": (0.2, 1.5), "Theta": (0.7, 3.5), "Alpha": (5.0, 12.0), "Beta": (9.0, 22.0), "Gamma": (10.0, 30.0)},
    "Meditation": {"Delta": (0.4, 3.0), "Theta": (3.0, 7.0), "Alpha": (8.0, 18.0), "Beta": (6.0, 15.0), "Gamma": (3.0, 15.0)},
}

def generate_dataset(samples=10000):
    data = []
    states = list(estados.keys())
    state_weights = [0.35, 0.15, 0.15, 0.25, 0.1]  # Distribución para crear desbalance de clases
    for _ in range(samples):
        state = np.random.choice(states, p=state_weights)
        frequencies = estados[state]
        # Ruido gaussiano correlacionado para simular interacciones entre bandas
        base_noise = np.random.normal(0, 0.15)
        record = {
            "State": state,
            "Delta": np.clip(np.random.normal(loc=np.mean(frequencies["Delta"]), scale=0.2) + base_noise * 0.1, *frequencies["Delta"]),
            "Theta": np.clip(np.random.normal(loc=np.mean(frequencies["Theta"]), scale=0.4) + base_noise * 0.2, *frequencies["Theta"]),
            "Alpha": np.clip(np.random.normal(loc=np.mean(frequencies["Alpha"]), scale=0.8) + base_noise * 0.3, *frequencies["Alpha"]),
            "Beta": np.clip(np.random.normal(loc=np.mean(frequencies["Beta"]), scale=1.5) + base_noise * 0.4, *frequencies["Beta"]),
            "Gamma": np.clip(np.random.normal(loc=np.mean(frequencies["Gamma"]), scale=2.5) + base_noise * 0.5, *frequencies["Gamma"]),
            "Noise": np.random.normal(0, 0.15),  # Ruido adicional
        }
        # Simulación de variabilidad específica del sujeto y artefactos
        if np.random.random() < 0.15:  # 15% de probabilidad de desplazamiento específico del sujeto
            shift = np.random.normal(0, 0.3)
            for band in ["Delta", "Theta", "Alpha", "Beta", "Gamma"]:
                record[band] += shift
                record[band] = np.clip(record[band], *frequencies[band])
        if np.random.random() < 0.2:  # 20% de probabilidad de artefacto
            band = np.random.choice(["Delta", "Theta", "Alpha", "Beta", "Gamma"])
            record[band] += np.random.normal(0, 0.5)
            record[band] = np.clip(record[band], *frequencies[band])
        data.append(record)
    return pd.DataFrame(data)

# Creación del modelo neural
def create_model(input_shape, num_classes):
    model = Sequential([
        Dense(32, activation='relu', input_shape=(input_shape,), kernel_regularizer=l2(0.005)),
        Dropout(0.3),
        Dense(16, activation='relu', kernel_regularizer=l2(0.005)),
        Dropout(0.3),
        Dense(num_classes, activation='softmax'),
    ])
    
    optimizer = Adam(learning_rate=0.0003)
    model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# Entrenamiento del modelo
dataset = generate_dataset(samples=10000)
X = dataset[["Delta", "Theta", "Alpha", "Beta", "Gamma", "Noise"]].values
y = LabelEncoder().fit_transform(dataset["State"])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
y_train_categorical = to_categorical(y_train)
y_test_categorical = to_categorical(y_test)

model = create_model(X_train.shape[1], len(np.unique(y)))

# Entrenamiento con early stopping y reducción de tasa de aprendizaje
early_stopping = EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=2, min_lr=1e-6)

history = model.fit(
    X_train, y_train_categorical,
    validation_data=(X_test, y_test_categorical),
    epochs=20,
    batch_size=128,
    callbacks=[early_stopping, reduce_lr]
)

# Evaluación del modelo
test_loss, test_accuracy = model.evaluate(X_test, y_test_categorical)
print(f"Precisión final del modelo: {test_accuracy:.4f}")`;

const DemoPage: React.FC = () => {
  const [samples, setSamples] = useState<DataPoint[]>([]);
  const [currentSample, setCurrentSample] = useState<DataPoint | null>(null);
  const [prediction, setPrediction] = useState<string | null>(null);
  const [confidence, setConfidence] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);
  const [showTutorial, setShowTutorial] = useState<boolean>(true);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Brain state colors
  const stateColors: Record<string, string> = {
    "Anxiety": "#FF5252",
    "Euphoria": "#FFD54F",
    "Focus": "#4CAF50",
    "Happiness": "#42A5F5",
    "Meditation": "#7E57C2"
  };
  
  // Mock prediction with a simulated model
  const predictState = (sample: DataPoint): [string, number] => {
    // Calculate distances to each state's typical values
    const distances: Record<string, number> = {};
    let totalDistance = 0;
    
    // Define typical values for each state (center of ranges)
    const typicalValues = {
      "Anxiety": { Delta: 0.55, Theta: 1.75, Alpha: 4.0, Beta: 14.0, Gamma: 11.0 },
      "Euphoria": { Delta: 1.0, Theta: 2.4, Alpha: 10.0, Beta: 19.0, Gamma: 32.5 },
      "Focus": { Delta: 0.45, Theta: 1.1, Alpha: 6.5, Beta: 25.0, Gamma: 29.0 },
      "Happiness": { Delta: 0.85, Theta: 2.1, Alpha: 8.5, Beta: 15.5, Gamma: 20.0 },
      "Meditation": { Delta: 1.7, Theta: 5.0, Alpha: 13.0, Beta: 10.5, Gamma: 9.0 }
    };
    
    // Calculate Euclidean distance for each state
    for (const [state, values] of Object.entries(typicalValues)) {
      const squaredDiffs = [
        Math.pow(sample.Delta - values.Delta, 2),
        Math.pow(sample.Theta - values.Theta, 2),
        Math.pow(sample.Alpha - values.Alpha, 2),
        Math.pow(sample.Beta - values.Beta, 2),
        Math.pow(sample.Gamma - values.Gamma, 2)
      ];
      
      // Weigh different bands differently
      const weights = [0.15, 0.2, 0.25, 0.2, 0.2];
      const weightedSum = squaredDiffs.reduce((sum, val, idx) => sum + val * weights[idx], 0);
      const distance = Math.sqrt(weightedSum);
      
      // Invert distance to get similarity (higher is better)
      distances[state] = 1 / (1 + distance);
      totalDistance += distances[state];
    }
    
    // Normalize to get probabilities
    const probabilities: Record<string, number> = {};
    for (const state in distances) {
      probabilities[state] = distances[state] / totalDistance;
    }
    
    // Find the most likely state
    let maxProb = 0;
    let predictedState = "";
    for (const [state, prob] of Object.entries(probabilities)) {
      if (prob > maxProb) {
        maxProb = prob;
        predictedState = state;
      }
    }
    
    // Add noise to simulate model variations
    const noise = Math.random() * 0.1 - 0.05; // -0.05 to 0.05
    const confidenceWithNoise = Math.min(Math.max(maxProb + noise, 0.5), 0.98);
    
    return [predictedState, confidenceWithNoise];
  };
  
  // Generate a random sample based on a specific state (or random if not specified)
  const generateSample = (state?: string): DataPoint => {
    const estados = {
      "Anxiety": { Delta: [0.1, 1.0], Theta: [0.5, 3.0], Alpha: [2.0, 6.0], Beta: [8.0, 20.0], Gamma: [4.0, 18.0] },
      "Euphoria": { Delta: [0.2, 1.8], Theta: [0.8, 4.0], Alpha: [6.0, 14.0], Beta: [10.0, 28.0], Gamma: [20.0, 45.0] },
      "Focus": { Delta: [0.1, 0.8], Theta: [0.2, 2.0], Alpha: [3.0, 10.0], Beta: [15.0, 35.0], Gamma: [18.0, 40.0] },
      "Happiness": { Delta: [0.2, 1.5], Theta: [0.7, 3.5], Alpha: [5.0, 12.0], Beta: [9.0, 22.0], Gamma: [10.0, 30.0] },
      "Meditation": { Delta: [0.4, 3.0], Theta: [3.0, 7.0], Alpha: [8.0, 18.0], Beta: [6.0, 15.0], Gamma: [3.0, 15.0] }
    };
    
    // Choose a random state if none specified
    if (!state) {
      const states = Object.keys(estados);
      state = states[Math.floor(Math.random() * states.length)];
    }
    
    const frequencies = estados[state as keyof typeof estados];
    
    // Random value within each range
    const getValue = (range: number[]) => range[0] + Math.random() * (range[1] - range[0]);
    
    // Introduce some correlation between values (to make it more realistic)
    const baseNoise = Math.random() * 0.3 - 0.15;
    
    return {
      State: state as string,
      Delta: getValue(frequencies.Delta) + baseNoise * 0.1,
      Theta: getValue(frequencies.Theta) + baseNoise * 0.2,
      Alpha: getValue(frequencies.Alpha) + baseNoise * 0.3,
      Beta: getValue(frequencies.Beta) + baseNoise * 0.4,
      Gamma: getValue(frequencies.Gamma) + baseNoise * 0.5,
      Noise: Math.random() * 0.3
    };
  };
  
  // Add a new sample
  const addSample = () => {
    const newSample = generateSample();
    setSamples(prev => [...prev, newSample]);
    setCurrentSample(newSample);
    runPrediction(newSample);
  };
  
  // Run prediction on a sample
  const runPrediction = (sample: DataPoint) => {
    setLoading(true);
    
    // Simulate model inference time
    setTimeout(() => {
      const [predictedState, predictedConfidence] = predictState(sample);
      setPrediction(predictedState);
      setConfidence(predictedConfidence);
      setLoading(false);
      
      // Draw brain wave visualization
      drawBrainWaves(sample);
    }, 1200);
  };
  
  // Clear all samples
  const clearSamples = () => {
    setSamples([]);
    setCurrentSample(null);
    setPrediction(null);
    setConfidence(0);
    
    // Clear visualization
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
    }
  };
  
  // Draw brain wave visualization based on EEG values
  const drawBrainWaves = (sample: DataPoint) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const width = canvas.width;
    const height = canvas.height;
    
    // Setup wave parameters
    const waves = [
      { name: 'Delta', value: sample.Delta, freq: 2, amplitude: 15, color: '#2C3E50' },
      { name: 'Theta', value: sample.Theta, freq: 5, amplitude: 12, color: '#E74C3C' },
      { name: 'Alpha', value: sample.Alpha, freq: 10, amplitude: 10, color: '#3498DB' },
      { name: 'Beta', value: sample.Beta, freq: 20, amplitude: 8, color: '#2ECC71' },
      { name: 'Gamma', value: sample.Gamma, freq: 40, amplitude: 5, color: '#9B59B6' }
    ];
    
    // Draw labels
    ctx.textAlign = 'left';
    ctx.font = '12px Arial';
    
    // Calculate max value for normalization
    const maxValue = Math.max(
      sample.Delta, 
      sample.Theta, 
      sample.Alpha, 
      sample.Beta, 
      sample.Gamma
    );
    
    // Draw each wave
    waves.forEach((wave, index) => {
      const yPos = 40 + index * 50;
      
      // Draw wave label
      ctx.fillStyle = wave.color;
      ctx.fillText(`${wave.name}: ${wave.value.toFixed(2)}`, 10, yPos - 20);
      
      // Normalize wave amplitude based on its value relative to maximum
      const normalizedAmplitude = (wave.value / maxValue) * wave.amplitude;
      
      // Draw wave
      ctx.beginPath();
      ctx.strokeStyle = wave.color;
      ctx.lineWidth = 2;
      
      for (let x = 0; x < width; x++) {
        // Create wave pattern with frequency based on the wave type
        // and amplitude based on the wave value
        const y = yPos + Math.sin(x * 0.01 * wave.freq + Date.now() * 0.001) * normalizedAmplitude * 2;
        
        if (x === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      
      ctx.stroke();
    });
  };
  
  // Animation loop for continuous wave updates
  useEffect(() => {
    let animationFrameId: number;
    
    const animate = () => {
      if (currentSample) {
        drawBrainWaves(currentSample);
      }
      animationFrameId = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [currentSample]);
  
  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      {/* Header */}
      <section className="py-16 bg-gradient-to-br from-[#0A2463] via-[#3E92CC] to-[#732C7B] text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Demostración de IA y Neurociencia
          </h1>
          <p className="text-xl max-w-3xl mx-auto">
            Explora cómo la inteligencia artificial puede analizar patrones de ondas cerebrales
            para identificar estados emocionales y cognitivos.
          </p>
        </div>
      </section>
      
      {/* Demo Container */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            {/* Tutorial Modal */}
            {showTutorial && (
              <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
                <div className="bg-white p-6 rounded-2xl shadow-xl max-w-2xl mx-4">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold text-gray-800 flex items-center">
                      <Brain className="mr-2 text-purple-600" />
                      Cómo funciona esta demostración
                    </h2>
                    <button 
                      onClick={() => setShowTutorial(false)}
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                  
                  <div className="space-y-4 text-gray-600">
                    <p>
                      Esta demostración interactiva simula cómo la IA puede analizar las ondas cerebrales (EEG) para 
                      identificar diferentes estados mentales y emocionales.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-6">
                      <div className="bg-purple-50 p-4 rounded-lg">
                        <h3 className="font-semibold text-gray-800 mb-2">Ondas cerebrales</h3>
                        <ul className="space-y-1 list-disc pl-5">
                          <li><span className="font-medium">Delta (0.5-4 Hz):</span> Sueño profundo</li>
                          <li><span className="font-medium">Theta (4-8 Hz):</span> Meditación, creatividad</li>
                          <li><span className="font-medium">Alpha (8-13 Hz):</span> Relajación tranquila</li>
                          <li><span className="font-medium">Beta (13-30 Hz):</span> Actividad mental, concentración</li>
                          <li><span className="font-medium">Gamma (30+ Hz):</span> Procesamiento cognitivo de alto nivel</li>
                        </ul>
                      </div>
                      
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h3 className="font-semibold text-gray-800 mb-2">Estados mentales</h3>
                        <ul className="space-y-1 list-disc pl-5">
                          <li><span className="font-medium text-red-500">Ansiedad:</span> Alto Beta, bajo Alpha</li>
                          <li><span className="font-medium text-yellow-500">Euforia:</span> Alto Gamma y Beta</li>
                          <li><span className="font-medium text-green-500">Concentración:</span> Beta dominante</li>
                          <li><span className="font-medium text-blue-500">Felicidad:</span> Balance Alpha-Beta</li>
                          <li><span className="font-medium text-purple-500">Meditación:</span> Alto Alpha y Theta</li>
                        </ul>
                      </div>
                    </div>
                    
                    <p>
                      <strong>Cómo usar la demostración:</strong>
                    </p>
                    
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Haz clic en "Generar muestra" para crear datos EEG aleatorios</li>
                      <li>Observa cómo el modelo de IA analiza las ondas y predice el estado mental</li>
                      <li>Explora el código fuente para entender cómo funciona el modelo</li>
                    </ol>
                    
                    <div className="bg-yellow-50 p-4 rounded-lg mt-4">
                      <p className="text-sm">
                        <strong>Nota:</strong> Esta es una simulación educativa. En la realidad, el análisis de EEG 
                        y la clasificación de estados mentales son mucho más complejos y requieren hardware 
                        especializado y algoritmos más sofisticados.
                      </p>
                    </div>
                  </div>
                  
                  <button 
                    onClick={() => setShowTutorial(false)}
                    className="mt-6 w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-colors"
                  >
                    Comenzar la demostración
                  </button>
                </div>
              </div>
            )}
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left Column - Demo Controls */}
              <div className="lg:col-span-1">
                <div className="bg-white rounded-2xl shadow-lg p-6">
                  <h2 className="text-2xl font-bold mb-6 text-gray-800">Control de demostración</h2>
                  
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-gray-700 mb-3">Acciones</h3>
                      <div className="flex flex-col gap-3">
                        <button 
                          onClick={addSample}
                          className="inline-flex items-center justify-center px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-colors"
                        >
                          <PlusCircle size={18} className="mr-2" />
                          Generar muestra
                        </button>
                        
                        <button 
                          onClick={clearSamples}
                          className="inline-flex items-center justify-center px-4 py-3 bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium rounded-lg transition-colors"
                          disabled={samples.length === 0}
                        >
                          <Trash2 size={18} className="mr-2" />
                          Borrar datos
                        </button>
                        
                        <button 
                          onClick={() => setShowTutorial(true)}
                          className="inline-flex items-center justify-center px-4 py-3 bg-blue-50 hover:bg-blue-100 text-blue-700 font-medium rounded-lg transition-colors"
                        >
                          <HelpCircle size={18} className="mr-2" />
                          Mostrar tutorial
                        </button>
                      </div>
                    </div>
                    
                    <div className="border-t pt-6">
                      <h3 className="text-lg font-medium text-gray-700 mb-3">Muestras generadas</h3>
                      {samples.length === 0 ? (
                        <div className="bg-gray-50 rounded-lg p-4 text-gray-500 text-center">
                          No hay muestras generadas todavía.
                        </div>
                      ) : (
                        <div className="max-h-64 overflow-y-auto pr-2">
                          <div className="space-y-2">
                            {samples.map((sample, index) => (
                              <div 
                                key={index}
                                onClick={() => {
                                  setCurrentSample(sample);
                                  runPrediction(sample);
                                }}
                                className={`p-3 rounded-lg cursor-pointer transition-colors ${
                                  currentSample === sample 
                                    ? 'bg-purple-100 border border-purple-300' 
                                    : 'bg-gray-50 hover:bg-gray-100'
                                }`}
                              >
                                <div className="flex justify-between items-center">
                                  <span className="font-medium text-gray-700">Muestra #{index + 1}</span>
                                  <span 
                                    className="px-2 py-1 text-xs font-medium rounded-full"
                                    style={{ 
                                      backgroundColor: `${stateColors[sample.State]}20`,
                                      color: stateColors[sample.State]
                                    }}
                                  >
                                    {sample.State}
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Right Column - Visualization & Prediction */}
              <div className="lg:col-span-2">
                <div className="bg-white rounded-2xl shadow-lg p-6 h-full">
                  <h2 className="text-2xl font-bold mb-6 text-gray-800">Visualización y predicción</h2>
                  
                  {currentSample ? (
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-medium text-gray-700 mb-3">Ondas cerebrales</h3>
                        <div className="bg-gray-50 rounded-xl p-4 overflow-hidden">
                          <canvas 
                            ref={canvasRef} 
                            width={600} 
                            height={300} 
                            className="w-full h-64"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-medium text-gray-700 mb-3">Análisis</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="bg-gray-50 rounded-xl p-4">
                            <h4 className="font-medium text-gray-700 mb-2">Valores de ondas</h4>
                            <div className="space-y-2">
                              {Object.entries(currentSample)
                                .filter(([key]) => key !== 'State' && key !== 'Noise')
                                .map(([key, value]) => (
                                  <div key={key} className="flex justify-between items-center">
                                    <span className="text-gray-600">{key}:</span>
                                    <span className="font-medium">{value.toFixed(2)}</span>
                                  </div>
                                ))}
                            </div>
                          </div>
                          
                          <div className="bg-gray-50 rounded-xl p-4">
                            <h4 className="font-medium text-gray-700 mb-2">Predicción del modelo</h4>
                            
                            {loading ? (
                              <div className="flex items-center justify-center h-24">
                                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-700"></div>
                              </div>
                            ) : prediction ? (
                              <div className="space-y-3">
                                <div className="flex justify-between items-center">
                                  <span className="text-gray-600">Estado detectado:</span>
                                  <span 
                                    className="font-bold text-lg"
                                    style={{ color: stateColors[prediction] }}
                                  >
                                    {prediction}
                                  </span>
                                </div>
                                
                                <div>
                                  <span className="text-gray-600 text-sm">Confianza del modelo:</span>
                                  <div className="mt-1 h-4 bg-gray-200 rounded-full overflow-hidden">
                                    <div 
                                      className="h-full rounded-full transition-all duration-500"
                                      style={{ 
                                        width: `${confidence * 100}%`,
                                        backgroundColor: stateColors[prediction]
                                      }}
                                    ></div>
                                  </div>
                                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                                    <span>0%</span>
                                    <span>{(confidence * 100).toFixed(1)}%</span>
                                    <span>100%</span>
                                  </div>
                                </div>
                                
                                <div className="text-sm text-gray-500 mt-2">
                                  <p>
                                    Estado verdadero: <span className="font-medium">{currentSample.State}</span>
                                    {prediction === currentSample.State ? (
                                      <span className="text-green-500 ml-2">✓ Correcto</span>
                                    ) : (
                                      <span className="text-red-500 ml-2">✗ Incorrecto</span>
                                    )}
                                  </p>
                                </div>
                              </div>
                            ) : (
                              <div className="text-center text-gray-500 py-6">
                                Genere una muestra para ver la predicción.
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-96 text-center">
                      <Brain size={64} className="text-gray-300 mb-4" />
                      <p className="text-gray-500 max-w-md">
                        Haz clic en "Generar muestra" para crear datos EEG aleatorios y ver 
                        cómo el modelo de IA predice el estado mental.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            {/* Code Section */}
            <div className="mt-8 bg-white rounded-2xl shadow-lg p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800">Código del modelo de IA</h2>
                <button className="inline-flex items-center text-gray-700 hover:text-gray-900">
                  <Download size={18} className="mr-1" />
                  <span>Descargar</span>
                </button>
              </div>
              
              <div className="bg-gray-900 rounded-xl overflow-hidden">
                <CodeHighlighter code={MODEL_CODE} language="python" />
              </div>
              
              <div className="mt-6 bg-blue-50 p-4 rounded-lg text-blue-800">
                <p className="text-sm">
                  <strong>Nota:</strong> Este código muestra cómo se puede construir un modelo de 
                  red neuronal para clasificar estados mentales basados en datos de EEG. En un entorno 
                  de producción, se utilizarían modelos más complejos, datos reales y un preprocesamiento 
                  más sofisticado.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DemoPage;