import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BrainCircuit, Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <nav 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/90 backdrop-blur-md shadow-md py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center text-primary">
            <BrainCircuit size={32} className={`mr-2 ${isScrolled ? 'text-primary' : 'text-white'}`} />
            <span className={`text-xl font-bold ${isScrolled ? 'text-primary' : 'text-white'}`}>
              Neuroconciencia-IA
            </span>
          </Link>
          
          <div className="hidden md:flex space-x-8">
            {[
              { name: 'Inicio', path: '/' },
              { name: '¿Qué es?', path: '/about' },
              { name: 'Artículos', path: '/articles' },
              { name: 'Demostración', path: '/demo' },
              { name: 'Contacto', path: '/contact' },
            ].map(item => (
              <Link 
                key={item.name}
                to={item.path}
                className={`
                  ${isScrolled ? 'text-gray-700' : 'text-white'} 
                  hover:text-purple-600 transition-colors duration-300
                  ${location.pathname === item.path ? 'font-semibold' : 'font-medium'}
                `}
              >
                {item.name}
              </Link>
            ))}
          </div>
          
          <div className="md:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className={`${isScrolled ? 'text-gray-700' : 'text-white'}`}
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg py-4 px-4 flex flex-col space-y-4 transition-all">
          {[
            { name: 'Inicio', path: '/' },
            { name: '¿Qué es?', path: '/about' },
            { name: 'Artículos', path: '/articles' },
            { name: 'Demostración', path: '/demo' },
            { name: 'Contacto', path: '/contact' },
          ].map(item => (
            <Link 
              key={item.name}
              to={item.path}
              className={`block text-gray-700 hover:text-purple-600 transition-colors duration-300 ${
                location.pathname === item.path ? 'font-semibold' : 'font-medium'
              }`}
            >
              {item.name}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
};

export default Navbar;