import React, { useEffect, useRef } from 'react';

const NeuralAnimation: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas to fill the screen
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    handleResize();
    window.addEventListener('resize', handleResize);

    // Neural network nodes
    interface Node {
      x: number;
      y: number;
      radius: number;
      vx: number;
      vy: number;
      connections: number[];
      pulseSpeed: number;
      pulsePhase: number;
    }

    // Create nodes
    const nodes: Node[] = [];
    const nodeCount = Math.min(window.innerWidth / 100, 15); // Adjust node count based on screen width

    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        radius: Math.random() * 2 + 2,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        connections: [],
        pulseSpeed: 0.01 + Math.random() * 0.02,
        pulsePhase: Math.random() * Math.PI * 2
      });
    }

    // Create connections between nodes
    nodes.forEach((node, i) => {
      const connectionCount = Math.floor(Math.random() * 2) + 1;
      for (let j = 0; j < connectionCount; j++) {
        const target = Math.floor(Math.random() * nodeCount);
        if (target !== i && !node.connections.includes(target)) {
          node.connections.push(target);
        }
      }
    });

    // Animation loop
    let animationFrameId: number;
    let time = 0;

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      time += 0.01;

      // Update and draw nodes
      nodes.forEach((node, i) => {
        // Update position with boundary check
        node.x += node.vx;
        node.y += node.vy;

        if (node.x < 0 || node.x > canvas.width) node.vx *= -1;
        if (node.y < 0 || node.y > canvas.height) node.vy *= -1;
        
        // Pulse effect
        const pulse = 0.5 + 0.5 * Math.sin(time * node.pulseSpeed + node.pulsePhase);
        
        // Draw connections
        node.connections.forEach(targetIndex => {
          const target = nodes[targetIndex];
          
          // Calculate distance
          const dx = target.x - node.x;
          const dy = target.y - node.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          // Only draw connections within a certain range
          if (distance < canvas.width / 3) {
            const opacity = (1 - distance / (canvas.width / 3)) * 0.6 * pulse;
            
            ctx.beginPath();
            ctx.moveTo(node.x, node.y);
            ctx.lineTo(target.x, target.y);
            ctx.strokeStyle = `rgba(255, 255, 255, ${opacity})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        });
        
        // Draw node
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.radius * (0.8 + 0.4 * pulse), 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${0.3 + 0.3 * pulse})`;
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return <canvas ref={canvasRef} className="absolute inset-0" />;
};

export default NeuralAnimation;